import { supabase } from './supabase';

export const storage = {
  async get(key: string, _isJson = false) {
    if (key === 'badminton-sessions-v3') {
      const { data, error } = await supabase
        .from('badminton_sessions')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching sessions:', error);
        return null;
      }

      const mapped = (data || []).map((row: any) => ({
        id: row.id,
        name: row.name,
        venue: row.venue,
        date: row.date,
        time: row.time,
        courts: row.courts,
        courtFeeTotal: row.court_fee_total,
        shuttleFee: row.shuttle_fee,
        maxPlayers: row.max_players ?? 12,
        note: row.note,
        signups: row.signups ?? [],
        waitlist: row.waitlist ?? [],
        shuttlesUsed: row.shuttles_used ?? 0,
        confirmedPresent: row.confirmed_present,
        finalPerPerson: row.final_per_person ?? 0,
        finalPresentCount: row.final_present_count,
        finalNote: row.final_note,
        createdAt: new Date(row.created_at).getTime(),
      }));

      return { value: JSON.stringify(mapped) };
    }

    if (key === 'badminton-settings') {
      const { data, error } = await supabase
        .from('badminton_settings')
        .select('*')
        .eq('id', 'global')
        .maybeSingle();

      if (error) {
        console.error('Error fetching settings:', error);
        return null;
      }

      if (!data) return null;
      return { value: JSON.stringify({ qrImage: data.qr_image }) };
    }

    // admins key
    if (key === 'badminton-admins') {
      const { data, error } = await supabase
        .from('badminton_identities')
        .select('value')
        .eq('key', 'badminton-admins')
        .maybeSingle();
      if (error) return null;
      return data ? { value: data.value } : { value: '[]' };
    }

    // identity key
    // admins key
    if (key === 'badminton-admins' || key.startsWith('vote:')) {
      const { data } = await supabase
        .from('badminton_identities')
        .select('value')
        .eq('key', key)
        .maybeSingle();
      return data ? { value: data.value } : { value: key === 'badminton-admins' ? '[]' : 'null' };
    }

    if (key.startsWith('identity:') || key.startsWith('identity_phone:')) {
      const { data, error } = await supabase
        .from('badminton_identities')
        .select('value')
        .eq('key', key)
        .maybeSingle();

      if (error) return null;
      return data ? { value: data.value } : null;
    }

    return null;
  },

  async set(key: string, value: string, _isJson = false) {
    if (key === 'badminton-sessions-v3') {
      const sessions = JSON.parse(value);

      const { data: existing } = await supabase
        .from('badminton_sessions')
        .select('id');

      const existingIds = new Set((existing || []).map((r: any) => r.id));
      const incomingIds = new Set(sessions.map((s: any) => s.id));

      const toDelete = [...existingIds].filter(id => !incomingIds.has(id));
      if (toDelete.length > 0) {
        await supabase
          .from('badminton_sessions')
          .delete()
          .in('id', toDelete);
      }

      if (sessions.length > 0) {
        const rows = sessions.map((s: any) => ({
          id: s.id,
          name: s.name ?? '',
          venue: s.venue ?? '',
          date: s.date,
          time: s.time,
          courts: s.courts ?? '',
          court_fee_total: Number(s.courtFeeTotal) || 0,
          shuttle_fee: Number(s.shuttleFee) || 0,
          max_players: Number(s.maxPlayers) || 12,
          note: s.note ?? '',
          signups: s.signups ?? [],
          waitlist: s.waitlist ?? [],
          shuttles_used: s.shuttlesUsed ?? 0,
          confirmed_present: s.confirmedPresent ?? null,
          final_per_person: s.finalPerPerson ?? 0,
          final_present_count: s.finalPresentCount ?? null,
          final_note: s.finalNote ?? '',
          created_at: s.createdAt
            ? new Date(s.createdAt).toISOString()
            : new Date().toISOString(),
        }));

        const { error } = await supabase
          .from('badminton_sessions')
          .upsert(rows, { onConflict: 'id' });

        if (error) {
          console.error('Error saving sessions:', error);
        }
      }
    }

    if (key === 'badminton-settings') {
      const settings = JSON.parse(value);
      const { error } = await supabase
        .from('badminton_settings')
        .upsert({
          id: 'global',
          qr_image: settings.qrImage ?? null,
          updated_at: new Date().toISOString(),
        });

      if (error) {
        console.error('Error saving settings:', error);
      }
    }

    // admins key
    if (key === 'badminton-admins') {
      await supabase
        .from('badminton_identities')
        .upsert({ key: 'badminton-admins', value, updated_at: new Date().toISOString() }, { onConflict: 'key' });
    }

    // admins key
    if (key === 'badminton-admins' || key.startsWith('vote:')) {
      await supabase
        .from('badminton_identities')
        .upsert({ key, value, updated_at: new Date().toISOString() }, { onConflict: 'key' });
    }

    // identity key
    if (key.startsWith('identity:') || key.startsWith('identity_phone:')) {
      await supabase
        .from('badminton_identities')
        .upsert({
          key,
          value,
          updated_at: new Date().toISOString(),
        }, { onConflict: 'key' });
    }
  },
};

if (typeof window !== 'undefined') {
  (window as any).storage = storage;
}
