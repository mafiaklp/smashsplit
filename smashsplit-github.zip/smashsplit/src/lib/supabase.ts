import { createClient } from '@supabase/supabase-js';

const SUPABASE_URL = 'https://caoltmgvosputhxgsmpm.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImNhb2x0bWd2b3NwdXRoeGdzbXBtIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMyODA3MDgsImV4cCI6MjA4ODg1NjcwOH0.KplMw21F8VWdIgMTjZpR_zOJA34sej7eCVgjJiezZ7s';

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
